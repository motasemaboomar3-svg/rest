class AppConfig {
  // ✅ عدّل هذا إذا تغيّر رابط لوحة التحكم/API
  static const String baseUrl = 'http://localhost:2532';
  static const Duration apiTimeout = Duration(seconds: 20);
}
